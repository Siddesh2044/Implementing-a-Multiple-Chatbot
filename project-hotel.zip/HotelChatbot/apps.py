from django.apps import AppConfig


class HotelChatbotConfig(AppConfig):
    name = 'HotelChatbot'
