from django.contrib import admin
from ManageHotels.models import Photo

# Registering the Photo model to the django admin
admin.site.register(Photo)
